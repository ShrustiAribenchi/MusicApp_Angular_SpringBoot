import { Component, OnInit } from '@angular/core';
import { NapsterService} from '../napster.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-songs',
  templateUrl: './songs.component.html',
  styleUrls: ['./songs.component.css']
})
export class SongsComponent implements OnInit {

  tartist: boolean = true;
  talbum: boolean = false;
  tvideo: boolean = false;
  tsongs: boolean = false;

  dataArray: any[] = [];
  albumArray: any[] = [];
  albTrackLinks: any[]=[];
  albSongs: any[] = [];
  constructor(private napsterServices: NapsterService, private router: Router) { }

  ngOnInit(): void {
    // this.napsterServices.getTopTracks()
    // .subscribe((response:any) =>{ 
    //   // console.log('Data',response);
    //   this.dataArray = response.tracks;
    //   // console.log(this.dataArray);
    // });

    this.napsterServices.getAlbum().subscribe((response:any) =>
    {
      this.albumArray = response.albums;
      for(let alb of this.albumArray){
        this.albTrackLinks.push(alb.links.tracks.href);
        this.napsterServices.getAlbTracks(alb.links.tracks.href).subscribe((res) =>{
          this.albSongs.push(res);
     
        });
      }
    //  console.log(this.albTrackLinks);
    
    });
    // console.log(this.albSongs);

    for(let alb of this.albTrackLinks){
    this.napsterServices.getAlbTracks(alb).subscribe((response:any)=>
    {
      this.albSongs.push(response.tracks);
      // console.log(this.albSongs);
      // console.log("hello");
    });
 

  }
   
  }
  toggle(str: string) {
    if(str == "artist") {
      this.tartist = true;
      this.talbum = false;
      this.tvideo = false;
      this.tsongs = false;
      return this.tartist;
    } else if(str == "album") {
      this.tartist = false;
      this.tvideo = false;
      this.talbum = true;
      this.tsongs = false;
      return this.talbum;
    }else if(str == "track"){
        this.tartist = false;
    this.talbum = false; 
    this.tsongs = true;
    this.tvideo = false;
    return this.tsongs;
    }
    this.tartist = false;
    this.tvideo = true;
    this.talbum = false;
    this.tsongs = false;
    return this.tvideo;
  }
  fetchAlbum(album){
    this.router.navigate(['/album', "here you pass the selected album's Link"]);
  }

}
