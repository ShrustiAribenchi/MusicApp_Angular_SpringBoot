export class User {
    name: string = '';
    password: string = '';
    email: string = '';
    secretKey: string = '';
    displayPicture: string = '';
    // constructor(name: string, pass: string, email: string, secret: string, dp: string) {
	// 	this.name = name;
	// 	this.password = pass;
	// 	this.email = email;
    //     this.secretKey = secret;
    //     this.displayPicture = dp;
	// }
}