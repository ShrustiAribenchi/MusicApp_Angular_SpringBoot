export class Recommends {
	useremail: string;
	songName: string;
	songUrl: string;
	recommend: string;
	
	// constructor(email: string, song: string, url: string, rec: string) {
	// 	this.useremail = email;
	// 	this.songName = song;
	// 	this.songUrl = url;
	// 	this.recommend = rec;
	// }
}