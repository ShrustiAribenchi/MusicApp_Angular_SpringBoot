export class Favourites {
	useremail: string;
	songName: string;
	songUrl: string;
	favourite: string;
	// constructor(email: string, song: string, url: string, fav: string) {
	// 	this.useremail = email;
	// 	this.songName = song;
	// 	this.songUrl = url;
	// 	this.favourite = fav;
	// }
}