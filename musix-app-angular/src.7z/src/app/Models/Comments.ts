export class Comments {
    comment: string;
	useremail: string;
	songName: string;
	
	
	// constructor(email: string, song: string, com: string) {
	// 	this.useremail = email;
	// 	this.songName = song;
	// 	this.comment = com;
	// }
}