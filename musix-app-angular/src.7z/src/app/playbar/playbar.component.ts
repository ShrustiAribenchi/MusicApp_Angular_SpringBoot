import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-playbar',
  templateUrl: './playbar.component.html',
  styleUrls: ['./playbar.component.css']
})
export class PlaybarComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
